<?php
/**
 * Plugin Name:       Flat101-news
 * Plugin URI:        flavionottalgiovanni.com
 * Description:       Bloque dinamico para mostrar &quot;notas de prensa&quot;
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            Flavio Nottalgiovanni
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       flat101-news
 *
 * @package           flat101-news
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function flat101_news_flat101_news_block_init() {
	register_block_type( __DIR__ . '/build', array(
		'render_callback' => 'flat101_news_flat101_news_block_render_news_content'
	) );
}
add_action( 'init', 'flat101_news_flat101_news_block_init' );

function flat101_news_flat101_news_block_render_news_content($attr, $content) {
	$args = array(
		'numberposts'	=> $attr['numberOfItems'],
		'post_type'	=> $attr['typePost'],
	);
	$dinamic = $attr['dinamycPosts'];
	
	if( $dinamic ){
		$my_posts = get_posts( $args );
	
		if( ! empty( $my_posts ) ){
			if(!wp_is_mobile()){$num_cols = $attr['columns'] > 1 ? strval( $attr['columns'] ) : '1';}else{$num_cols = '1';}
			$output = '<div ' . get_block_wrapper_attributes() . '>';
			$output .= '<h1 style="text-align: ' . $attr['align'] . '">Notas de prensa</h1>';
			$output .= '<ul class="wp-block-flat101-news-flat101-news__post-items columns-' . $num_cols . '">';

			foreach ( $my_posts as $p ){

				$title = $p->post_title ? $p->post_title : 'Default title';
				$url = esc_url( get_permalink( $p->ID ) );
				$thumbnail = has_post_thumbnail( $p->ID ) ? get_the_post_thumbnail( $p->ID, 'medium', array( 'class' => 'wp-block-flat101-news-flat101-news__post-thumbnail' ) ) : '';
				
				
				$output .= '<li>';
				$output .= '<div class="post-container">';
				if( ! empty( $thumbnail ) && $attr['displayThumbnail'] ){
				$output .= '' . $thumbnail;
				}				
				if( $attr['displayDate'] ){
					$output .= '<time datetime="' . esc_attr( get_the_date( 'j M', $p ) ) . '">' . esc_html( get_the_date( 'j M', $p ) ) . '</time>';
				}
				$output .= '</div>';
				$output .= '<h5><a href="' . $url . '">' . $title . '</a></h5>';
				if( get_the_excerpt( $p ) && $attr['displayExcerpt'] ){
					$excerpt = get_the_excerpt($p);

					$excerpt = substr($excerpt, 0, 260);
					$result = substr($excerpt, 0, strrpos($excerpt, ' '));
					$output .= '<p class="excerpt">' . $result . '</p>';
				}
				
				$output .= '</li>';
				
			}
			$output .= '</ul>';
			$output .= '</h1>';
		}
		return $output ?? '<strong>Sorry. No posts matching your criteria!</strong>';	
	} else {
		//$output = '<div ' . get_block_wrapper_attributes() . '>';
		//return $output ??'<strong>Sorry. Dinamic posts is disabled!</strong>';  

  		return $content; // Print output
	}
	
}
